import React from "react";

import "./CompanyProfile.css";

const CompanyProfile = () => {
  return <></>;
};
export default CompanyProfile;
