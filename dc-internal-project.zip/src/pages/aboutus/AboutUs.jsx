import React from "react";

import CompanyProfile from "../../Components/companyprofile/CompanyProfile";
import SideNav from "../../Components/sidenav/SideNav";
// import "./AboutUs.css";

const AboutUs = () => {
  return (
    <>
      <div>
        <SideNav />
        <CompanyProfile />
      </div>
    </>
  );
};

export default AboutUs;
